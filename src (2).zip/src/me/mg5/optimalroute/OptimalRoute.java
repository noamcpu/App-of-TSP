package me.mg5.optimalroute;
	
import java.util.ArrayList;

import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
	
	public class OptimalRoute {
	
		public static void main(String[] args) {
			long startTime = System.nanoTime();
			//Unirest.setTimeouts(0, 0);
			Adress ad1 = new Adress ("Petah Tikva" , "Arlozerov", "5");
			Adress ad2 = new Adress ("Netanya" , "Harav Yanna", "5");
			Adress ad3 = new Adress ("Petah Tikva" , "Hertzel", "73");
			Adress ad4 = new Adress ("Tel Aviv" , "Hamasger", "3");
			

			Coordinate coord1 = Algoritem.getCoordinate(ad1);
			Coordinate coord2 = Algoritem.getCoordinate(ad2);
			Coordinate coord3 = Algoritem.getCoordinate(ad3);
			Coordinate coord4 = Algoritem.getCoordinate(ad4);
			
			ArrayList<Coordinate> coords = new ArrayList<Coordinate>();
			coords.add(coord2);
			coords.add(coord3);
			coords.add(coord4);
			
			ArrayList<Coordinate> ads = Algoritem.CalculateOptimalRoute(false, coords, coord1);
			for(int i = 0; i<ads.size(); i++) {
				System.out.println(ads.get(i).toString());
			}
			long endTime   = System.nanoTime();
			long totalTime = endTime - startTime;
			System.out.println(totalTime); 

		}
	
	}