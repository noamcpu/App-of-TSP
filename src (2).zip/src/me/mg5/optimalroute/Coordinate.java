package me.mg5.optimalroute;

public class Coordinate {
	private float north;
	private float west;
	
	@Override
	public String toString() {
		return north + "," + west;
	}
	public float getNorth() {
		return north;
	}
	public float getWest() {
		return west;
	}
	public Coordinate(double b, double d) {
		this.north = (float) b ;
		this.west = (float) d;
	}

	 
	
}
