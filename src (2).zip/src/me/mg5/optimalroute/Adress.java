package me.mg5.optimalroute;

public class Adress {
	
	private String city;
	private String adress;
	private String number;
	
	
	public Adress(String city, String adress, String number) {
		this.city = city;
		this.adress = adress;
		this.number = number;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", adress=" + adress + ", number=" + number + "]";
	}
	public String getCity() {
		return city;
	}
	public String getAdress() {
		return adress;
	}
	public String getNumber() {
		return number;
	}	
	
	
}
