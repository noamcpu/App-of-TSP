package me.mg5.optimalroute;

import java.util.ArrayList;

import org.json.JSONObject;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

public class Algoritem {

	public static RouteParam getRouteParams(Coordinate coord1, Coordinate coord2) throws UnirestException {
		String URI = "https://api.tomtom.com/routing/1/calculateRoute/" + coord1.toString() + ":" + coord2.toString()
				+ "/json?instructionsType=text&language=en-US&vehicleHeading=90&sectionType=traffic&report=effectiveSettings&routeType=eco&traffic=true&avoid=unpavedRoads&travelMode=car&vehicleMaxSpeed=120&vehicleCommercial=false&vehicleEngineType=combustion&key=OKmkVNYe3caVPvtT3tAa45IE3IRL6mrg";
		Unirest.setTimeouts(0, 0);
		HttpResponse<JsonNode> response = Unirest.get(URI).header("X-Mashape-Authorization", null).asJson();
		JSONObject obj = response.getBody().getObject().getJSONArray("routes").getJSONObject(0)
				.getJSONObject("summary");

		return new RouteParam(obj.optDouble("travelTimeInSeconds") / 60.0, obj.optDouble("lengthInMeters") / 1000.0);
	}

	public static Coordinate getCoordinate(Adress address) throws UnirestException {
		String URI = "https://api.tomtom.com/search/2/geocode/" + address.getAdress() + " " + address.getNumber() + " "
				+ address.getCity() + " Israel.JSON?key=OKmkVNYe3caVPvtT3tAa45IE3IRL6mrg";
		Unirest.setTimeouts(0, 0);
		HttpResponse<JsonNode> response = Unirest.get(URI).header("X-Mashape-Authorization", null).asJson();
		JSONObject position = response.getBody().getObject().getJSONArray("results").getJSONObject(0)
				.getJSONArray("entryPoints").getJSONObject(0).getJSONObject("position");
		return new Coordinate(position.getDouble("lat"), position.getDouble("lon"));
	}

	public static ArrayList<Coordinate> CalculateOptimalRoute(boolean param, ArrayList<Coordinate> coords,
			Coordinate startCoord) throws UnirestException {
		ArrayList<Coordinate> ads = new ArrayList<Coordinate>();
		ads.add(startCoord);
		Coordinate coord;
		Coordinate nextCoord = startCoord;
		RouteParam r;
		float min;
		while (!coords.isEmpty()) {
			r = getRouteParams(nextCoord, coords.get(0));
			if (param)
				min = r.getMinutes();
			else
				min = r.getDistance();
			coord = coords.get(0);
			for (int i = 1; i < coords.size(); i++) {
				r = getRouteParams(nextCoord, coords.get(i));
				if (param && r.getMinutes() > min) {
					min = r.getMinutes();
					coord = coords.get(i);
				}
				if (!param && min > r.getDistance()) {
					min = r.getDistance();
					coord = coords.get(i);
				}
			}
			coords.remove(coord);
			ads.add(coord);
			nextCoord = coord;
		}
		return ads;

	}

}
