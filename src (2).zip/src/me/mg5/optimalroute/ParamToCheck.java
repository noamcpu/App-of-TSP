package me.mg5.optimalroute;

public enum ParamToCheck {
	
	DISTANCE,
	TIME
}
