package me.mg5.optimalroute;

public class RouteParam {
	
	private float minutes;
	private float distance;
	
	public RouteParam (double minutes, double distance) {
		this.minutes = (float) minutes;
		this.distance = (float) distance;
	}

	public float getMinutes() {
		return minutes;
	}

	public float getDistance() {
		return distance;
	}

	@Override
	public String toString() {
		return "minutes=" + minutes + ", distance=" + distance +"KM";
	}	
	
	

}
